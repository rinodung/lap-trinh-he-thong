/*   Cache Simulator
 *   Author: foo
 */

#include "cachelab.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <getopt.h>
#include <string.h>
#include <math.h>

/* a cache_line has a valid bit, tag bits, and an LRU count */
typedef struct cache_line
{
  int valid;
  int tag;
  int lruCount;
} cache_line;

/*
   updateCache performs the "heavy lifting" of cache work. Determines hits,
   misses, and evicts and updates the information for the simulator.
*/
void updateCache(int v, int tag, int setIndex, int E, int* hits, int* misses,
                 int* evicts, int lruVal, struct cache_line** cache) {
  int i;
  /* Loop through the cache at the given setIndex */
  for(i = 0; i < E; i++)
    {
      if(cache[setIndex][i].valid && cache[setIndex][i].tag == tag)
	{
	  /* We have a hit */
	  cache[setIndex][i].lruCount = lruVal;
	  *hits = *hits + 1;

	  if(v)
	    printf(" hit");
	  return;
	}
    }

  /* We have a miss */
 *misses = *misses + 1;

  if(v)
    printf(" miss");

  /* We need to figure out if there is an empty spot to put the element into */
  int emptySpot = 0;
  for(i = 0; i < E; i++)
    {
      if(cache[setIndex][i].valid == 0)
	{
	  /* i is an empty spot */
	  cache[setIndex][i].valid = 1;
	  cache[setIndex][i].tag = tag;
	  cache[setIndex][i].lruCount = lruVal;
	  emptySpot = 1;
	  return;
	}
    }

  if(!emptySpot)
    {
      /* We know there wasn't an empty spot, so we must evict */
      int minLRU = cache[setIndex][0].lruCount;
      int indexToEvict = 0;
      for(i = 0; i < E; i++)
	{
	  if(cache[setIndex][i].lruCount < minLRU)
	    {
	      minLRU = cache[setIndex][i].lruCount;
	      indexToEvict = i;
	    }
	}

      cache[setIndex][indexToEvict].lruCount = lruVal;
      cache[setIndex][indexToEvict].tag = tag;
      cache[setIndex][indexToEvict].valid = 1;
      *evicts = *evicts + 1;

      if (v)
	printf(" eviction");
      return;
    }
}

/*
   getFileContents reads the lines of the trace and calls updateCache to
   perform the cache work
*/

void getFileContents(int v, int s, int E, int b, char* t, cache_line** cache)
{
  /* Open the file and perform the caching */
  char* operation = malloc(sizeof(int));
  long long* address = malloc(sizeof(long long));
  int* size = malloc(sizeof(int));

  long long tag;
  long long setIndex;

  int* hits = malloc(sizeof(int));
  int* misses = malloc(sizeof(int));
  int* evicts = malloc(sizeof(int));

  int lruVal = 0;

  FILE* filename;
  filename = fopen(t, "r");

  /* Only if the file is valid */
  if(filename) {
    while(fscanf(filename, " %c %llx,%d\n", operation, address, size) != EOF)
      {
	/* Determine which instruction we are looking at */
	if(*operation == 'I')
	  continue;
	else
	  {
	    if(v)
	      printf("%c %llx,%d", *operation, *address, *size);

	    /* Get the tag and setIndex bits */
	    tag = ((*address) >> (b + s));
	    setIndex = ((*address) >> b) & ((1 << s) - 1);

	    /* L and S are the same for our purposes */
	    updateCache(v, tag, setIndex, E, hits, misses, evicts,
			lruVal, cache);
	    lruVal++;

	    /* M is a load followed by a store */
	    if(operation[0] == 'M')
	      {
		updateCache(v, tag, setIndex, E, hits, misses, evicts,
			    lruVal, cache);
		lruVal++;
	      }
	  }

	if(v)
	  printf("\n");
      }
    fclose(filename);
  } else {
    printf("Could not open file");
    return;
  }
  printSummary(*hits, *misses, *evicts);

  free(hits);
  free(misses);
  free(evicts);
  free(operation);
  free(address);
  free(size);
  return;
}

int main(int argc, char *argv[])
{
  /* get the arguments given to the function */
  int v = 0;
  int s;
  int E;
  int b;
  char* t;
  int opt;

  while((opt = getopt( argc, argv, "vs:E:b:t:" )) != -1) {
    switch( opt ) {
    case 'v':
      v = 1;
      break;

    case 's':
      s = atoi(optarg);
      break;

    case 'E':
      E = atoi(optarg);
      break;

    case 'b':
      b = atoi(optarg);
      break;

    case 't':
      t = optarg;
      break;
    }
  }
  /* define the cache struct as a 2-D array of cache_lines */
  int numSets = pow(2, s);
  cache_line** cache = malloc(sizeof(cache_line) * numSets);
  int i = 0;
  for(i = 0; i < numSets; i++)
    cache[i] = malloc(sizeof(cache_line) * E);

  /* start getting and processing the file information */
  getFileContents(v, s, E, b, t, cache);

  for(i = 0; i < numSets; i++)
    free(cache[i]);
  free(cache);
  return 0;
}
